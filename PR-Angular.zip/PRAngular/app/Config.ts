﻿export class Config {
	public static PATIENT_ENDPOINT = 'api/patient/';
}

export enum DBOperation {
	CREATE = 1,
	UPDATE = 2,
	DELETE = 3
}