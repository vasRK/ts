"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Config = /** @class */ (function () {
    function Config() {
    }
    Config.PATIENT_ENDPOINT = 'api/patient/';
    return Config;
}());
exports.Config = Config;
var DBOperation;
(function (DBOperation) {
    DBOperation[DBOperation["CREATE"] = 1] = "CREATE";
    DBOperation[DBOperation["UPDATE"] = 2] = "UPDATE";
    DBOperation[DBOperation["DELETE"] = 3] = "DELETE";
})(DBOperation = exports.DBOperation || (exports.DBOperation = {}));
//# sourceMappingURL=Config.js.map