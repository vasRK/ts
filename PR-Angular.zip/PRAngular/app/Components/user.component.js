"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var forms_1 = require("@angular/forms");
var user_1 = require("../Models/user");
var PatientService_1 = require("../Service/PatientService");
var Config_1 = require("../Config");
var ng2_bs3_modal_1 = require("ng2-bs3-modal/ng2-bs3-modal");
var UserComponent = /** @class */ (function () {
    function UserComponent(fb, _patientService) {
        this.fb = fb;
        this._patientService = _patientService;
        this.isLoading = false;
        this.genderList = [user_1.Gender[0], user_1.Gender[1]];
        this.userFrm = this.fb.group({
            Id: [''],
            FirstName: ['', forms_1.Validators.required],
            LastName: [''],
            Email: [''],
            Gender: new forms_1.FormControl(this.genderList),
            DOB: [''],
            State: [''],
            City: [''],
        });
        this.users = new Array();
        this.modalTitle = "Add Patient";
        this.modalBtnTitle = "Save";
    }
    UserComponent.prototype.ngOnInit = function () {
        this.loadUsers();
    };
    UserComponent.prototype.loadUsers = function () {
        var _this = this;
        this.isLoading = true;
        this._patientService.getAll(Config_1.Config.PATIENT_ENDPOINT + "getall")
            .subscribe(function (users) {
            console.log(users);
            _this.users = users;
            _this.isLoading = false;
        }, function (error) { return _this.msg = error; });
        this.getCities(2);
        //for (let ctr = 0; ctr < 10; ctr++) {
        //	var userRndm = new User();
        //	userRndm.Id = ctr;
        //	userRndm.Email = "user" + ctr + "_email@gmail.com";
        //	userRndm.FirstName = "first_name_" + ctr;
        //	userRndm.LastName = "last_name_" + ctr;
        //	userRndm.Gender = Gender[Gender[ctr % 2]];
        //	userRndm.City = "city_" + ctr;
        //	userRndm.State = "state_" + ctr;
        //	userRndm.DOB = Date.now();
        //	this.users.push(userRndm);
        //}
    };
    UserComponent.prototype.getGenderString = function (gender) {
        return user_1.Gender[gender];
    };
    UserComponent.prototype.getDOBString = function (dob) {
        var _dob = new Date(dob);
        var dd = _dob.getDate();
        var ddStr = dd.toString();
        var mm = _dob.getMonth() + 1; //January is 0!
        var mmStr = mm.toString();
        var year = _dob.getFullYear();
        if (dd < 10) {
            ddStr = '0' + ddStr;
        }
        if (mm < 10) {
            mmStr = '0' + mmStr;
        }
        return ddStr + "-" + mmStr + "-" + year;
    };
    UserComponent.prototype.editUser = function (userId) {
        this.dbops = Config_1.DBOperation.CREATE;
        console.log("edit user id" + userId);
        this.modal.open();
    };
    UserComponent.prototype.deleteUser = function (userId) {
        console.log("delete user id" + userId);
    };
    UserComponent.prototype.getCities = function (stateId) {
        this._patientService.get(Config_1.Config.PATIENT_ENDPOINT + "getCities?stateId=" + stateId)
            .subscribe(function (cities) {
            console.log(cities);
        });
    };
    UserComponent.prototype.onSubmit = function (formData) {
        var _this = this;
        this.msg = "";
        switch (this.dbops) {
            case Config_1.DBOperation.CREATE:
                this._patientService.post(Config_1.Config.PATIENT_ENDPOINT + "save", formData._value).subscribe(function (data) {
                    if (data == 1) //Success
                     {
                        _this.msg = "Data successfully added.";
                        _this.loadUsers();
                    }
                    else {
                        _this.msg = "There is some issue in saving records, please contact to system administrator!";
                    }
                    _this.modal.dismiss();
                }, function (error) {
                    _this.msg = error;
                });
                break;
            case Config_1.DBOperation.UPDATE:
                this._patientService.put(Config_1.Config.PATIENT_ENDPOINT, formData._value.Id, formData._value).subscribe(function (data) {
                    if (data == 1) //Success
                     {
                        _this.msg = "Data successfully updated.";
                        _this.loadUsers();
                    }
                    else {
                        _this.msg = "There is some issue in saving records, please contact to system administrator!";
                    }
                    _this.modal.dismiss();
                }, function (error) {
                    _this.msg = error;
                });
                break;
            case Config_1.DBOperation.DELETE:
                this._patientService.delete(Config_1.Config.PATIENT_ENDPOINT, formData._value.Id).subscribe(function (data) {
                    if (data == 1) //Success
                     {
                        _this.msg = "Data successfully deleted.";
                        _this.loadUsers();
                    }
                    else {
                        _this.msg = "There is some issue in saving records, please contact to system administrator!";
                    }
                    _this.modal.dismiss();
                }, function (error) {
                    _this.msg = error;
                });
                break;
        }
    };
    __decorate([
        core_1.ViewChild('patientForm'),
        __metadata("design:type", ng2_bs3_modal_1.ModalComponent)
    ], UserComponent.prototype, "modal", void 0);
    UserComponent = __decorate([
        core_1.Component({
            templateUrl: 'app/Components/user.component.html'
        }),
        __metadata("design:paramtypes", [forms_1.FormBuilder, PatientService_1.PatientService])
    ], UserComponent);
    return UserComponent;
}());
exports.UserComponent = UserComponent;
//# sourceMappingURL=user.component.js.map