﻿import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { IUser, User, Gender } from '../Models/user';
import { PatientService } from '../Service/PatientService';
import { Config, DBOperation } from '../Config';

import { ModalComponent } from 'ng2-bs3-modal/ng2-bs3-modal';

@Component({
	templateUrl: 'app/Components/user.component.html'
})

export class UserComponent implements OnInit {

	@ViewChild('patientForm') modal: ModalComponent;
	users: IUser[];
	user: IUser;
	msg: string;
	isLoading: boolean = false;
	userFrm: FormGroup;
	modalTitle: string;
	modalBtnTitle: string;
	genderList: string[];
	dbops: DBOperation;

	constructor(private fb: FormBuilder, private _patientService: PatientService) {
		this.genderList = [Gender[0], Gender[1]];
		this.userFrm = this.fb.group({
			Id: [''],
			FirstName: ['', Validators.required],
			LastName: [''],
			Email: [''],
			Gender: new FormControl(this.genderList),
			DOB: [''],
			State: [''],
			City: [''],
		});

		this.users = new Array<IUser>();
		this.modalTitle = "Add Patient";
		this.modalBtnTitle = "Save";
	}

	ngOnInit(): void {

		this.loadUsers();
	}

	loadUsers(): void {
		this.isLoading = true;

		this._patientService.getAll(Config.PATIENT_ENDPOINT + "getall")
			.subscribe(users => {

				console.log(users);

				this.users = users;
				this.isLoading = false;
			},
				error => this.msg = <any>error);

		this.getCities(2);

		//for (let ctr = 0; ctr < 10; ctr++) {

		//	var userRndm = new User();
		//	userRndm.Id = ctr;
		//	userRndm.Email = "user" + ctr + "_email@gmail.com";
		//	userRndm.FirstName = "first_name_" + ctr;
		//	userRndm.LastName = "last_name_" + ctr;
		//	userRndm.Gender = Gender[Gender[ctr % 2]];
		//	userRndm.City = "city_" + ctr;
		//	userRndm.State = "state_" + ctr;
		//	userRndm.DOB = Date.now();

		//	this.users.push(userRndm);
		//}
	}

	getGenderString(gender: Gender): string {
		return Gender[gender];
	}

	getDOBString(dob: number): string {

		var _dob = new Date(dob);
		var dd = _dob.getDate();
		var ddStr = dd.toString();
		var mm = _dob.getMonth() + 1; //January is 0!
		var mmStr = mm.toString();

		var year = _dob.getFullYear();

		if (dd < 10) {
			ddStr = '0' + ddStr;
		}

		if (mm < 10) {
			mmStr = '0' + mmStr;
		}

		return ddStr + "-" + mmStr + "-" + year;
	}

	addNewPatient(): void {
		this.dbops = DBOperation.CREATE;
		console.log("add new user");

		this.modal.open();
	}

	editUser(userId: number): void {
		this.dbops = DBOperation.UPDATE;
		console.log("edit user id" + userId);

		this.modal.open();
	}

	deleteUser(userId: number): void {
		console.log("delete user id" + userId);
	}

	getCities(stateId: number): void {

		this._patientService.get(Config.PATIENT_ENDPOINT + "getCities?stateId=" + stateId)
			.subscribe(cities => {
				console.log(cities);
			});
	}

	onSubmit(formData: any) {
		this.msg = "";

		switch (this.dbops) {
			case DBOperation.CREATE:
				this.modal.close();
				this._patientService.post(Config.PATIENT_ENDPOINT + "save", formData._value).subscribe(
					data => {
						if (data == 1) //Success
						{
							this.msg = "Data successfully added.";
							this.loadUsers();
						}
						else {
							this.msg = "There is some issue in saving records, please contact to system administrator!"
						}

						this.modal.dismiss();
					},
					error => {
						this.msg = error;
					}
				);
				break;
			case DBOperation.UPDATE:
				this._patientService.put(Config.PATIENT_ENDPOINT, formData._value.Id, formData._value).subscribe(
					data => {
						if (data == 1) //Success
						{
							this.msg = "Data successfully updated.";
							this.loadUsers();
						}
						else {
							this.msg = "There is some issue in saving records, please contact to system administrator!"
						}

						this.modal.dismiss();
					},
					error => {
						this.msg = error;
					}
				);
				break;
			case DBOperation.DELETE:
				this._patientService.delete(Config.PATIENT_ENDPOINT, formData._value.Id).subscribe(
					data => {
						if (data == 1) //Success
						{
							this.msg = "Data successfully deleted.";
							this.loadUsers();
						}
						else {
							this.msg = "There is some issue in saving records, please contact to system administrator!"
						}

						this.modal.dismiss();
					},
					error => {
						this.msg = error;
					}
				);
				break;

		}
	}

}