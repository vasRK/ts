﻿import { Component } from "@angular/core"

@Component({
	selector: "pr-app",
	templateUrl: '/app/app.component.html'
})

export class AppComponent {

}