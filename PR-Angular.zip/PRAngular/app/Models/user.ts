﻿export interface IUser {
	Id: number,
	Email: string,
	FirstName: string,
	LastName: string,
	Gender: Gender,
	City: string,
	State: string,
	DOB: number,
}

export class User implements IUser {
	Id: number;
	Email: string;
	FirstName: string;
	LastName: string;
	Gender: Gender;
	City: string;
	State: string;
	DOB: number;

	constructor() {

	};
}

export enum Gender {
	Male = 0,
	Female = 1
}