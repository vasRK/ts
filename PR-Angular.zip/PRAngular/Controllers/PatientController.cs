﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using PRAngular.Models;

namespace PRAngular.Controllers
{
	[RoutePrefix("api/patient")]
	public class PatientApiController : ApiController
	{
		private IPatientAppContext _db = new PatientAppContext();

		public PatientApiController()
		{
		}

		public PatientApiController(IPatientAppContext db)
		{
			_db = db;
		}

		[HttpGet]
		[Route("getCities")]
		public async Task<IHttpActionResult> GetAllCities(int stateId)
		{
			var patients = new List<string>() { "A", "B", "C" };

			return Ok(patients);
		}

		[HttpGet]
		[Route("getall")]
		public async Task<IHttpActionResult> GetAllPatients()
		{
			var patients = new List<Models.Patient>();

			for (var ctr = 0; ctr < 10; ctr++)
			{
				var patient = new Models.Patient();
				patient.Id = ctr;
				patient.Email = "user" + ctr + "_email@gmail.com";
				patient.FirstName = "first_name_" + ctr;
				patient.LastName = "last_name_" + ctr;
				patient.Gender = (Models.Gender)(ctr % 2);
				patient.City = "city_" + ctr;
				patient.State = "state_" + ctr;
				patient.DOB = DateTime.Now;

				patients.Add(patient);
			}

			return Ok(patients);
		}


		[HttpGet]
		[Route("details")]
		public async Task<HttpResponseMessage> GetPatient(int id)
		{
			var res = Request.CreateResponse<Models.Patient>(HttpStatusCode.OK, new Models.Patient()
			{
				FirstName = "Patient 1"
			}); ;

			return res;
		}

		[Route("save")]
		[HttpPost]
		public async Task<string> SavePatient([FromBody]Models.Patient patient)
		{
			return "Saved patient";
		}

		[Route("delete")]
		[HttpDelete]
		public async Task<string> DeletePatient([FromBody]Models.Patient patient)
		{
			return "Saved patient";
		}



		[Route("search")]
		[HttpPost]
		public async Task<HttpResponseMessage> SearchPatient([FromBody]Models.Patient patient)
		{
			var res = Request.CreateResponse(HttpStatusCode.OK, "Find patient");
			return res;
		}
	}
}
