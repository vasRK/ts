﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRAngular.Models
{
	public interface IPatientAppContext : IDisposable
	{
		DbSet<Patient> Patients { get; }
		int SaveChanges();
		void MarkAsModified(Patient patient);
	}
}
