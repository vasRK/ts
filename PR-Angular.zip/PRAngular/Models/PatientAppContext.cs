﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace PRAngular.Models
{
	public class PatientAppContext : DbContext, IPatientAppContext
	{
		public PatientAppContext() : base("name=PatientAppContext")
		{
		}

		public DbSet<Patient> Patients { get; set; }

		public void MarkAsModified(Patient patient)
		{
			Entry(patient).State = EntityState.Modified;
		}
	}
}